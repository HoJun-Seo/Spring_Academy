package com.example.ex01.model.admin.dao;

import com.example.ex01.model.admin.dto.AdminDTO;

public interface AdminDAO {
	public String loginCheck(AdminDTO dto);
}
