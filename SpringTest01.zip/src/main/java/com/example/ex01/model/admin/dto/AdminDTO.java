package com.example.ex01.model.admin.dto;

import lombok.Data;

@Data
public class AdminDTO {
	
	private String userid;
}
