package com.example.ex01.model.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class ProductDTO {
	private String name;
	private double price;
	
//	public String getName() {
//		return name;
//	}
//	public void setName(String name) {
//		this.name = name;
//	}
//	public double getPrice() {
//		return price;
//	}
//	public void setPrice(double price) {
//		this.price = price;
//	}
//	public ProductDTO(String name, double price) {
//		super();
//		this.name = name;
//		this.price = price;
//	}
//	public ProductDTO() {
//		super();
//	}
	
}
