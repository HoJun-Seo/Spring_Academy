package com.example.ex01.service.admin;

import com.example.ex01.model.admin.dto.AdminDTO;

public interface AdminService {
	public String loginCheck(AdminDTO dto);
}
